# All In One
Upload to GitHub -> Actions -> Build APK -> download artifact.
